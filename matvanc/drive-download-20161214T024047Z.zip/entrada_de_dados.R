######################################
#######Entrada de dados###############
######################################

getwd()
setwd("C:/Users/Larissa/Mat Avan/Comp_IME2/Comp_IME/Trab")

data1 <-read.csv("Edu-Data.csv",header =T)
data1
