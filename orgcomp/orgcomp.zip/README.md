Trabalho de OrgComp 2016
========================

#Modo de uso
```
ruby menu.rb
```

#Alunos
Bruno Vieira Costa
Lucas Ricarte Rogério Teixeira
Davi Coelho Amorim

